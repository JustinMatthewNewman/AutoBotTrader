import cbpro
import constants

BUY = 'buy'
SELL = 'sell'

class TradingSystems:

    def __init__(self, cb_pro_client):
        self.client = cb_pro_client

    def trade(self, action, limitPrice, quantity):
        if action == BUY:
            response = self.client.buy(
                price=limitPrice,
                size=self.round(quantity*0.99),
                order_type='limit',
                product_id='BTC-USD',
                overdraft_enabled=False
            )
        elif action == SELL:
            response = self.client.sell(
                price=limitPrice,
                size=self.round(quantity),
                order_type='limit',
                product_id='BTC-USD',
                overdraft_enabled=False
            )

        print(response)
        

    def veiwAccounts(self, accountCurrency):
        accounts = self.client.get_accounts()
        account = list(filter(lambda x: x['currency'] == accountCurrency, accounts))[0]
        return account

    def accountInfo(self, accountCurrency):
        accounts = self.client.get_accounts()
        return accounts

    def veiwOrder(self, order_id):
        return self.client.get_order(order_id)


    def gettingCurrentPriceOfBitcoin(self):
        tick = self.client.get_product_ticker(product_id='BTC-USD')
        return tick['bid']

    def round(self, val):
        newVal = int(val * 10000000)/10000000
        return newVal

if __name__ == "__main__":
    print("Welcome to the Crypto-Trader 3000! \n")
    auth_client = cbpro.AuthenticatedClient(constants.cbpro_publicKey, constants.cbpro_secret, constants.cbpro_passphrase,
                                  api_url="https://api-public.sandbox.pro.coinbase.com")

    tradingSystems = TradingSystems(auth_client)
    print("Client Authenticated.")
    usdBalance = tradingSystems.veiwAccounts('USD')['balance']
    btcBalance = tradingSystems.veiwAccounts('BTC')['balance']
    currentPrice = tradingSystems.gettingCurrentPriceOfBitcoin()
    
    a = True
    while(a):
        var = input("Type /help for list of commands: ")
        if (var == "/buy"):
            tradingSystems.trade(BUY, float(currentPrice), float(usdBalance) /float(currentPrice))
        if (var == "/sell"):
            tradingSystems.trade(SELL, float(currentPrice), float(btcBalance))
        if (var == "/getInfo"):
            print("$ USD -> BTC = " + tradingSystems.gettingCurrentPriceOfBitcoin() + "\n")
            print("Display Balance from Coinbase pro: \n\n")
            print(tradingSystems.veiwAccounts('USD')['balance'] + "\n")
        if (var == "/exit"):
            a = False
            break
        if (var == "/accountInfo"):
            print(tradingSystems.accountInfo('USD'))
        else :
            print("Command list: \n ")
            print("/help")
            print("/buy")
            print("/sell")
            print("/getInfo")
            print("/accountInfo")
            print("/exit")
            print("\n")



    


    

