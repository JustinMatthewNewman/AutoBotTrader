import coinbase

coinbase_api_key = 'wKy700kzLqJVGZjX'
coinbase_api_secret = 'cGGQbZi7Wb2CGnaAhWKaLSdeJgJgu6FD'

coinbase = coinbase.Coinbase.with_api_key(coinbase_api_key, coinbase_api_secret)

balance = coinbase.get_balance()
print('Balance is ' + balance + ' BTC')
