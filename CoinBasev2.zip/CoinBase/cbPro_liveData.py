from cbpro.websocket_client import WebsocketClient
import cbpro

from constants import (cbpro_passphrase, cbpro_publicKey, cbpro_secret)

class TextWebsocketClient(cbpro.WebsocketClient):
    def on_open(self):
        self.url2 = 'wss://ws-feed-public.pro.coinbase.com'
        self.url = 'wss://ws-feed.pro.coinbase.com'
        self.message_count = 0
    
    def on_message(self, msg):
        self.message_count += 1
        msg_type = msg.get('type',None)
        if msg_type == 'ticker':
            time_val = msg.get('time', ('-'*27))
            price_val = msg.get('price',None)
            price_val = float(price_val) if price_val is not None else 'None'
            product_id = msg.get('product_id', None)
            print(f"{time_val:30} {price_val:.3f} {product_id}\tchannel type:{msg_type}")

    def on_close(self):
        print(f"<---WebsocketClient connection closed--->\n\tTotal Messages: {self.message_count}")
    
stream = TextWebsocketClient(products=['BTC-USD'], channels=['ticker'])
stream.start()