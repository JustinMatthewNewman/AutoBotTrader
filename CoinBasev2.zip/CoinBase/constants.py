cbpro_passphrase = '3063562'
cbpro_secret2 = 'Gxws69i2S5BZvXaizaTaPdYMmfNLBZiNuAUN2SCVUa9fwpDnOLekf9Qn4I0U+7+jsjApdyBB17vblg8J8ZDm1w=='
cbpro_publicKey2 = '89c0a3fd1716f6a1c096ecd5c1f185c6'

cbpro_secret = 'rNpszDg+fmn8Ug8qTDZmkoNaxFpaT2PNJrZPc/YIshZW4Gq5G2EEEZe5zoYmuShZBpupMumrC4ORoJAwlSeoEw=='
cbpro_publicKey = '14fe53e990fe69f34b1a73c1bc51afe7'